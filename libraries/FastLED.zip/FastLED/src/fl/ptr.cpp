#include "fl/ptr.h"
#include "fl/referent.h"

#include "fl/namespace.h"

namespace fl {

// Ptr implementation is all in the header file

} // namespace fl
