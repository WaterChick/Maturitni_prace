#pragma once

#include "fl/slice.h"

namespace fl {

template<typename T>
using span = Slice<T>;

};
