#include "fl/referent.h"

#include "fl/namespace.h"

namespace fl {

// Since the header has inline implementations, we don't need implementations here
// The header file contains all the method definitions

} // namespace fl
