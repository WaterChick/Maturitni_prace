#pragma once

#include <stddef.h>  // ok include
#include <stdint.h>  // ok include
