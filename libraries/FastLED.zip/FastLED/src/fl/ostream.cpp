#include "fl/ostream.h"

namespace fl {

// Global cout instance for immediate output
ostream cout;

// endl manipulator instance
const endl_t endl;

} // namespace fl
