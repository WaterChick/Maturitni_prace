var searchData=
[
  ['clear_0',['clear',['../class_m_d___m_a_x72_x_x.html#a5ce5b733333d776ef94e0cc36e1043cf',1,'MD_MAX72XX::clear(void)'],['../class_m_d___m_a_x72_x_x.html#ac57b7cd49a465e7f5f3027a1eac46242',1,'MD_MAX72XX::clear(uint8_t startDev, uint8_t endDev)'],['../class_m_d___m_a_x72_x_x.html#acff691690cb5848980f10be9facbe086',1,'MD_MAX72XX::clear(uint8_t buf)']]],
  ['col_5fsize_1',['COL_SIZE',['../_m_d___m_a_x72xx_8h.html#a99468544016f0abb855e6415c629ec29',1,'MD_MAX72xx.h']]],
  ['connections_2',['System Connections',['../page_connect.html',1,'index']]],
  ['control_3',['control',['../class_m_d___m_a_x72_x_x.html#aa54ba8b079710f6b4e9f9721e2e09c68',1,'MD_MAX72XX::control(uint8_t dev, controlRequest_t mode, int value)'],['../class_m_d___m_a_x72_x_x.html#aeb43fa0c917e716b9d35eac72fb1dd45',1,'MD_MAX72XX::control(controlRequest_t mode, int value)'],['../class_m_d___m_a_x72_x_x.html#aa724a797235e28a43b8d127e4999537e',1,'MD_MAX72XX::control(uint8_t startDev, uint8_t endDev, controlRequest_t mode, int value)']]],
  ['controlrequest_5ft_4',['controlRequest_t',['../class_m_d___m_a_x72_x_x.html#a7c6d702fe0161b19448f35049e00bf4f',1,'MD_MAX72XX']]],
  ['controlvalue_5ft_5',['controlValue_t',['../class_m_d___m_a_x72_x_x.html#aadaf745b81100652dafeff2eb212f457',1,'MD_MAX72XX']]],
  ['copyright_6',['Copyright',['../page_copyright.html',1,'index']]],
  ['create_20and_20modify_20fonts_7',['Create and Modify Fonts',['../page_font_utility.html',1,'index']]],
  ['custom_20module_8',['Parola Custom Module',['../page_parola.html',1,'pageHardware']]]
];
